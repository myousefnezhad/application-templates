package io.github.kotlin.fibonacci

actual val firstElement: Int = 3
actual val secondElement: Int = 4