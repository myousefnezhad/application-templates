package io.github.kotlin.fibonacci

actual val firstElement: Int = 2
actual val secondElement: Int = 3