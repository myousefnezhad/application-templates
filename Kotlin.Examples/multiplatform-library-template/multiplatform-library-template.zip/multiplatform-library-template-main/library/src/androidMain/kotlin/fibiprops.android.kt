package io.github.kotlin.fibonacci

actual val firstElement: Int = 1
actual val secondElement: Int = 2